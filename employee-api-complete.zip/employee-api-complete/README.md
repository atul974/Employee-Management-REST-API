# Employee API
Run: mvn spring-boot:run
