package com.example.employeeapi.service;
import java.util.*;import org.springframework.stereotype.Service;
import com.example.employeeapi.entity.Employee;import com.example.employeeapi.dto.EmployeeDTO;import com.example.employeeapi.repository.EmployeeRepository;
@Service public class EmployeeService{
private final EmployeeRepository r; public EmployeeService(EmployeeRepository r){this.r=r;}
public List<Employee> all(){return r.findAll();}
public Employee one(Long id){return r.findById(id).orElse(null);}
public Employee create(EmployeeDTO d){Employee e=new Employee();e.setName(d.getName());e.setEmail(d.getEmail());e.setDepartment(d.getDepartment());e.setSalary(d.getSalary());return r.save(e);}
public Employee update(Long id,EmployeeDTO d){Employee e=one(id); if(e==null)return null; e.setName(d.getName());e.setEmail(d.getEmail());e.setDepartment(d.getDepartment());e.setSalary(d.getSalary()); return r.save(e);}
public boolean delete(Long id){if(!r.existsById(id))return false; r.deleteById(id); return true;}
}