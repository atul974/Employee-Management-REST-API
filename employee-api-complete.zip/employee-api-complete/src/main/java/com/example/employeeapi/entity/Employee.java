package com.example.employeeapi.entity;
import jakarta.persistence.*;
@Entity public class Employee{
@Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
private String name; private String email; private String department; private Double salary;
public Long getId(){return id;} public void setId(Long id){this.id=id;}
public String getName(){return name;} public void setName(String n){name=n;}
public String getEmail(){return email;} public void setEmail(String e){email=e;}
public String getDepartment(){return department;} public void setDepartment(String d){department=d;}
public Double getSalary(){return salary;} public void setSalary(Double s){salary=s;}
}