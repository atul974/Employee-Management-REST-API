package com.example.employeeapi.controller;
import java.util.*;import org.springframework.web.bind.annotation.*;import org.springframework.http.*;import jakarta.validation.Valid;
import com.example.employeeapi.entity.Employee;import com.example.employeeapi.dto.EmployeeDTO;import com.example.employeeapi.service.EmployeeService;
@RestController @RequestMapping("/api/employees")
public class EmployeeController{
private final EmployeeService s; public EmployeeController(EmployeeService s){this.s=s;}
@GetMapping public List<Employee> all(){return s.all();}
@GetMapping("/{id}") public ResponseEntity<Employee> one(@PathVariable Long id){Employee e=s.one(id);return e==null?ResponseEntity.notFound().build():ResponseEntity.ok(e);}
@PostMapping public ResponseEntity<Employee> create(@Valid @RequestBody EmployeeDTO d){return new ResponseEntity<>(s.create(d),HttpStatus.CREATED);}
@PutMapping("/{id}") public ResponseEntity<Employee> update(@PathVariable Long id,@Valid @RequestBody EmployeeDTO d){Employee e=s.update(id,d);return e==null?ResponseEntity.notFound().build():ResponseEntity.ok(e);}
@DeleteMapping("/{id}") public ResponseEntity<Void> del(@PathVariable Long id){return s.delete(id)?ResponseEntity.noContent().build():ResponseEntity.notFound().build();}
}