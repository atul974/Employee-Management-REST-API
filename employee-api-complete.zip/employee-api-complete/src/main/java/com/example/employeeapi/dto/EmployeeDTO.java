package com.example.employeeapi.dto;
import jakarta.validation.constraints.*;
public class EmployeeDTO{
@NotBlank private String name;
@NotBlank @Email private String email;
@NotBlank private String department;
@Min(1000) private Double salary;
public String getName(){return name;} public void setName(String n){name=n;}
public String getEmail(){return email;} public void setEmail(String e){email=e;}
public String getDepartment(){return department;} public void setDepartment(String d){department=d;}
public Double getSalary(){return salary;} public void setSalary(Double s){salary=s;}
}